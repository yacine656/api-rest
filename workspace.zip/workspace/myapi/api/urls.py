from django.urls import path
from .views import *

urlpatterns = [
    path ('hello-world', hello_world),
    path('chat-with-gpt', chat_with_gpt),
    path('hello/<name>', hello_person),
]

