import openai

openai.api_key = "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"
openai.api_base = "https://openrouter.ai/api/v1"

def open_ia_response(prompt):
    response = openai.ChatCompletion.create(
        model="openai/gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response["choices"][0]["message"]["content"]