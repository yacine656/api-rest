
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .open_ai_service import open_ia_response

@api_view(['GET'])

def hello_world(request):
    return Response("hello world !!")
@api_view(['GET'])
def hello_person(request,name) :
    return Response(f"Bonjour {name} !!")
@api_view(['POST'])
def chat_with_gpt(request):
    prompt = request.data.get('prompt')
    return Response(open_ia_response(prompt))