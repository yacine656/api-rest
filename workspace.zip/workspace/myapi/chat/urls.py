from .views import *
from django.contrib import admin
from django.urls import path
from django.urls import include
urlpatterns = [
    path('generate-schedule', generate_schedule),
    path('track-sleep', track_sleep),
    path('track-exercise', track_exercise),
    path('nutrition-tips', nutrition_tips ),
    path('life-balance-tips', life_balance_tips),
]
