from rest_framework.decorators import api_view
from rest_framework.response import Response
from .open_ai_service import *



@api_view(['POST'])
def generate_schedule(request):
    user_data = request.data  # Données utilisateur (heures de travail, préférences, etc.)
    prompt = f"Génère un emploi du temps équilibré avec sport, sommeil, travail et alimentation selon {user_data}."
    return Response({"schedule": open_ia_response(prompt)})


@api_view(['POST'])
def track_sleep(request):
    sleep_hours = request.data.get("sleep_hours")
    prompt = f"L'utilisateur a dormi {sleep_hours} heures. Analyse et conseils ?"
    return Response({"sleep_analysis": open_ia_response(prompt)})


@api_view(['POST'])
def track_exercise(request):
    exercise_data = request.data  # Type d'exercice, durée, intensité...
    prompt = f"Analyse cette session d'exercice : {exercise_data}."
    return Response({"exercise_analysis": open_ia_response(prompt)})


@api_view(['GET'])
def nutrition_tips(request):
    prompt = "Donne des conseils alimentaires pour un mode de vie équilibré."
    return Response({"nutrition_tips": open_ia_response(prompt)})


@api_view(['GET'])
def life_balance_tips(request):
    prompt = "Quels sont les meilleurs conseils pour équilibrer travail, sommeil, sport et alimentation ?"
    return Response({"life_balance_tips": open_ia_response(prompt)})